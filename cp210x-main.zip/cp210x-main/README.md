# cp210x

ESP32開発ボード(38Pin) (NodeMCU-32)
